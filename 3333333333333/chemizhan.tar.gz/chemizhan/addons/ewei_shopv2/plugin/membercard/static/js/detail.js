define([], function () {
    var modal = {};
    modal.init = function (params) {



    };
    return modal;
});